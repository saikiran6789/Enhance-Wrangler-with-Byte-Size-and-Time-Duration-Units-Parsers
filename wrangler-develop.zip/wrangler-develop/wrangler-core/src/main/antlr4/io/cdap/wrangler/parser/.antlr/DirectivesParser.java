// Generated from c:/Users/Sai/OneDrive/Documents/Desktop/Zeotap/wrangler-develop/wrangler-develop/wrangler-core/src/main/antlr4/io/cdap/wrangler/parser/Directives.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class DirectivesParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, OBrace=9, 
		CBrace=10, SColon=11, Or=12, And=13, Equals=14, NEquals=15, GTEquals=16, 
		LTEquals=17, Match=18, NotMatch=19, QuestionColon=20, StartsWith=21, NotStartsWith=22, 
		EndsWith=23, NotEndsWith=24, PlusEqual=25, SubEqual=26, MulEqual=27, DivEqual=28, 
		PerEqual=29, AndEqual=30, OrEqual=31, XOREqual=32, Pow=33, External=34, 
		GT=35, LT=36, Add=37, Subtract=38, Multiply=39, Divide=40, Modulus=41, 
		OBracket=42, CBracket=43, OParen=44, CParen=45, Assign=46, Comma=47, QMark=48, 
		Colon=49, Dot=50, At=51, Pipe=52, BackSlash=53, Dollar=54, Tilde=55, Bool=56, 
		Number=57, Identifier=58, Macro=59, Column=60, String=61, EscapeSequence=62, 
		Comment=63, Space=64;
	public static final int
		RULE_recipe = 0, RULE_statements = 1, RULE_directive = 2, RULE_ifStatement = 3, 
		RULE_ifStat = 4, RULE_elseIfStat = 5, RULE_elseStat = 6, RULE_expression = 7, 
		RULE_forStatement = 8, RULE_macro = 9, RULE_pragma = 10, RULE_pragmaLoadDirective = 11, 
		RULE_pragmaVersion = 12, RULE_codeblock = 13, RULE_identifier = 14, RULE_properties = 15, 
		RULE_propertyList = 16, RULE_property = 17, RULE_numberRanges = 18, RULE_numberRange = 19, 
		RULE_value = 20, RULE_ecommand = 21, RULE_config = 22, RULE_column = 23, 
		RULE_text = 24, RULE_number = 25, RULE_bool = 26, RULE_condition = 27, 
		RULE_command = 28, RULE_colList = 29, RULE_numberList = 30, RULE_boolList = 31, 
		RULE_stringList = 32, RULE_identifierList = 33;
	private static String[] makeRuleNames() {
		return new String[] {
			"recipe", "statements", "directive", "ifStatement", "ifStat", "elseIfStat", 
			"elseStat", "expression", "forStatement", "macro", "pragma", "pragmaLoadDirective", 
			"pragmaVersion", "codeblock", "identifier", "properties", "propertyList", 
			"property", "numberRanges", "numberRange", "value", "ecommand", "config", 
			"column", "text", "number", "bool", "condition", "command", "colList", 
			"numberList", "boolList", "stringList", "identifierList"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'if'", "'else'", "'for'", "'#pragma'", "'load-directives'", "'version'", 
			"'exp'", "'prop'", "'{'", "'}'", "';'", "'||'", "'&&'", "'=='", "'!='", 
			"'>='", "'<='", "'=~'", "'!~'", "'?:'", "'=^'", "'!^'", "'=$'", "'!$'", 
			"'+='", "'-='", "'*='", "'/='", "'%='", "'&='", "'|='", "'^='", "'^'", 
			"'!'", "'>'", "'<'", "'+'", "'-'", "'*'", "'/'", "'%'", "'['", "']'", 
			"'('", "')'", "'='", "','", "'?'", "':'", "'.'", "'@'", "'|'", "'\\'", 
			"'$'", "'~'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, "OBrace", "CBrace", 
			"SColon", "Or", "And", "Equals", "NEquals", "GTEquals", "LTEquals", "Match", 
			"NotMatch", "QuestionColon", "StartsWith", "NotStartsWith", "EndsWith", 
			"NotEndsWith", "PlusEqual", "SubEqual", "MulEqual", "DivEqual", "PerEqual", 
			"AndEqual", "OrEqual", "XOREqual", "Pow", "External", "GT", "LT", "Add", 
			"Subtract", "Multiply", "Divide", "Modulus", "OBracket", "CBracket", 
			"OParen", "CParen", "Assign", "Comma", "QMark", "Colon", "Dot", "At", 
			"Pipe", "BackSlash", "Dollar", "Tilde", "Bool", "Number", "Identifier", 
			"Macro", "Column", "String", "EscapeSequence", "Comment", "Space"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Directives.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public DirectivesParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RecipeContext extends ParserRuleContext {
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public TerminalNode EOF() { return getToken(DirectivesParser.EOF, 0); }
		public RecipeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_recipe; }
	}

	public final RecipeContext recipe() throws RecognitionException {
		RecipeContext _localctx = new RecipeContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_recipe);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68);
			statements();
			setState(69);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StatementsContext extends ParserRuleContext {
		public List<TerminalNode> Comment() { return getTokens(DirectivesParser.Comment); }
		public TerminalNode Comment(int i) {
			return getToken(DirectivesParser.Comment, i);
		}
		public List<MacroContext> macro() {
			return getRuleContexts(MacroContext.class);
		}
		public MacroContext macro(int i) {
			return getRuleContext(MacroContext.class,i);
		}
		public List<DirectiveContext> directive() {
			return getRuleContexts(DirectiveContext.class);
		}
		public DirectiveContext directive(int i) {
			return getRuleContext(DirectiveContext.class,i);
		}
		public List<TerminalNode> SColon() { return getTokens(DirectivesParser.SColon); }
		public TerminalNode SColon(int i) {
			return getToken(DirectivesParser.SColon, i);
		}
		public List<PragmaContext> pragma() {
			return getRuleContexts(PragmaContext.class);
		}
		public PragmaContext pragma(int i) {
			return getRuleContext(PragmaContext.class,i);
		}
		public List<IfStatementContext> ifStatement() {
			return getRuleContexts(IfStatementContext.class);
		}
		public IfStatementContext ifStatement(int i) {
			return getRuleContext(IfStatementContext.class,i);
		}
		public StatementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statements; }
	}

	public final StatementsContext statements() throws RecognitionException {
		StatementsContext _localctx = new StatementsContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_statements);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(82);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & -8917127262193582062L) != 0)) {
				{
				setState(80);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case Comment:
					{
					setState(71);
					match(Comment);
					}
					break;
				case Dollar:
					{
					setState(72);
					macro();
					}
					break;
				case Identifier:
					{
					setState(73);
					directive();
					setState(74);
					match(SColon);
					}
					break;
				case T__3:
					{
					setState(76);
					pragma();
					setState(77);
					match(SColon);
					}
					break;
				case T__0:
					{
					setState(79);
					ifStatement();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(84);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DirectiveContext extends ParserRuleContext {
		public CommandContext command() {
			return getRuleContext(CommandContext.class,0);
		}
		public List<CodeblockContext> codeblock() {
			return getRuleContexts(CodeblockContext.class);
		}
		public CodeblockContext codeblock(int i) {
			return getRuleContext(CodeblockContext.class,i);
		}
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public List<MacroContext> macro() {
			return getRuleContexts(MacroContext.class);
		}
		public MacroContext macro(int i) {
			return getRuleContext(MacroContext.class,i);
		}
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public List<NumberContext> number() {
			return getRuleContexts(NumberContext.class);
		}
		public NumberContext number(int i) {
			return getRuleContext(NumberContext.class,i);
		}
		public List<BoolContext> bool() {
			return getRuleContexts(BoolContext.class);
		}
		public BoolContext bool(int i) {
			return getRuleContext(BoolContext.class,i);
		}
		public List<ColumnContext> column() {
			return getRuleContexts(ColumnContext.class);
		}
		public ColumnContext column(int i) {
			return getRuleContext(ColumnContext.class,i);
		}
		public List<ColListContext> colList() {
			return getRuleContexts(ColListContext.class);
		}
		public ColListContext colList(int i) {
			return getRuleContext(ColListContext.class,i);
		}
		public List<NumberListContext> numberList() {
			return getRuleContexts(NumberListContext.class);
		}
		public NumberListContext numberList(int i) {
			return getRuleContext(NumberListContext.class,i);
		}
		public List<BoolListContext> boolList() {
			return getRuleContexts(BoolListContext.class);
		}
		public BoolListContext boolList(int i) {
			return getRuleContext(BoolListContext.class,i);
		}
		public List<StringListContext> stringList() {
			return getRuleContexts(StringListContext.class);
		}
		public StringListContext stringList(int i) {
			return getRuleContext(StringListContext.class,i);
		}
		public List<NumberRangesContext> numberRanges() {
			return getRuleContexts(NumberRangesContext.class);
		}
		public NumberRangesContext numberRanges(int i) {
			return getRuleContext(NumberRangesContext.class,i);
		}
		public List<PropertiesContext> properties() {
			return getRuleContexts(PropertiesContext.class);
		}
		public PropertiesContext properties(int i) {
			return getRuleContext(PropertiesContext.class,i);
		}
		public DirectiveContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_directive; }
	}

	public final DirectiveContext directive() throws RecognitionException {
		DirectiveContext _localctx = new DirectiveContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_directive);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(85);
			command();
			setState(101);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			while ( _alt!=1 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1+1 ) {
					{
					setState(99);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
					case 1:
						{
						setState(86);
						codeblock();
						}
						break;
					case 2:
						{
						setState(87);
						identifier();
						}
						break;
					case 3:
						{
						setState(88);
						macro();
						}
						break;
					case 4:
						{
						setState(89);
						text();
						}
						break;
					case 5:
						{
						setState(90);
						number();
						}
						break;
					case 6:
						{
						setState(91);
						bool();
						}
						break;
					case 7:
						{
						setState(92);
						column();
						}
						break;
					case 8:
						{
						setState(93);
						colList();
						}
						break;
					case 9:
						{
						setState(94);
						numberList();
						}
						break;
					case 10:
						{
						setState(95);
						boolList();
						}
						break;
					case 11:
						{
						setState(96);
						stringList();
						}
						break;
					case 12:
						{
						setState(97);
						numberRanges();
						}
						break;
					case 13:
						{
						setState(98);
						properties();
						}
						break;
					}
					} 
				}
				setState(103);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IfStatementContext extends ParserRuleContext {
		public IfStatContext ifStat() {
			return getRuleContext(IfStatContext.class,0);
		}
		public TerminalNode CBrace() { return getToken(DirectivesParser.CBrace, 0); }
		public List<ElseIfStatContext> elseIfStat() {
			return getRuleContexts(ElseIfStatContext.class);
		}
		public ElseIfStatContext elseIfStat(int i) {
			return getRuleContext(ElseIfStatContext.class,i);
		}
		public ElseStatContext elseStat() {
			return getRuleContext(ElseStatContext.class,0);
		}
		public IfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStatement; }
	}

	public final IfStatementContext ifStatement() throws RecognitionException {
		IfStatementContext _localctx = new IfStatementContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_ifStatement);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(104);
			ifStat();
			setState(108);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(105);
					elseIfStat();
					}
					} 
				}
				setState(110);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			}
			setState(112);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				{
				setState(111);
				elseStat();
				}
				break;
			}
			setState(114);
			match(CBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IfStatContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode OBrace() { return getToken(DirectivesParser.OBrace, 0); }
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public IfStatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStat; }
	}

	public final IfStatContext ifStat() throws RecognitionException {
		IfStatContext _localctx = new IfStatContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_ifStat);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(116);
			match(T__0);
			setState(117);
			expression();
			setState(118);
			match(OBrace);
			setState(119);
			statements();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElseIfStatContext extends ParserRuleContext {
		public TerminalNode CBrace() { return getToken(DirectivesParser.CBrace, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode OBrace() { return getToken(DirectivesParser.OBrace, 0); }
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public ElseIfStatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseIfStat; }
	}

	public final ElseIfStatContext elseIfStat() throws RecognitionException {
		ElseIfStatContext _localctx = new ElseIfStatContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_elseIfStat);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(121);
			match(CBrace);
			setState(122);
			match(T__1);
			setState(123);
			match(T__0);
			setState(124);
			expression();
			setState(125);
			match(OBrace);
			setState(126);
			statements();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElseStatContext extends ParserRuleContext {
		public TerminalNode CBrace() { return getToken(DirectivesParser.CBrace, 0); }
		public TerminalNode OBrace() { return getToken(DirectivesParser.OBrace, 0); }
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public ElseStatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseStat; }
	}

	public final ElseStatContext elseStat() throws RecognitionException {
		ElseStatContext _localctx = new ElseStatContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_elseStat);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			match(CBrace);
			setState(129);
			match(T__1);
			setState(130);
			match(OBrace);
			setState(131);
			statements();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionContext extends ParserRuleContext {
		public List<TerminalNode> OParen() { return getTokens(DirectivesParser.OParen); }
		public TerminalNode OParen(int i) {
			return getToken(DirectivesParser.OParen, i);
		}
		public TerminalNode CParen() { return getToken(DirectivesParser.CParen, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_expression);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(133);
			match(OParen);
			setState(138);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					setState(136);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case T__0:
					case T__1:
					case T__2:
					case T__3:
					case T__4:
					case T__5:
					case T__6:
					case T__7:
					case OBrace:
					case CBrace:
					case SColon:
					case Or:
					case And:
					case Equals:
					case NEquals:
					case GTEquals:
					case LTEquals:
					case Match:
					case NotMatch:
					case QuestionColon:
					case StartsWith:
					case NotStartsWith:
					case EndsWith:
					case NotEndsWith:
					case PlusEqual:
					case SubEqual:
					case MulEqual:
					case DivEqual:
					case PerEqual:
					case AndEqual:
					case OrEqual:
					case XOREqual:
					case Pow:
					case External:
					case GT:
					case LT:
					case Add:
					case Subtract:
					case Multiply:
					case Divide:
					case Modulus:
					case OBracket:
					case CBracket:
					case CParen:
					case Assign:
					case Comma:
					case QMark:
					case Colon:
					case Dot:
					case At:
					case Pipe:
					case BackSlash:
					case Dollar:
					case Tilde:
					case Bool:
					case Number:
					case Identifier:
					case Macro:
					case Column:
					case String:
					case EscapeSequence:
					case Comment:
					case Space:
						{
						setState(134);
						_la = _input.LA(1);
						if ( _la <= 0 || (_la==OParen) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						}
						break;
					case OParen:
						{
						setState(135);
						expression();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					} 
				}
				setState(140);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			}
			setState(141);
			match(CParen);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ForStatementContext extends ParserRuleContext {
		public TerminalNode OParen() { return getToken(DirectivesParser.OParen, 0); }
		public TerminalNode Identifier() { return getToken(DirectivesParser.Identifier, 0); }
		public TerminalNode Assign() { return getToken(DirectivesParser.Assign, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<TerminalNode> SColon() { return getTokens(DirectivesParser.SColon); }
		public TerminalNode SColon(int i) {
			return getToken(DirectivesParser.SColon, i);
		}
		public TerminalNode CParen() { return getToken(DirectivesParser.CParen, 0); }
		public TerminalNode OBrace() { return getToken(DirectivesParser.OBrace, 0); }
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public TerminalNode CBrace() { return getToken(DirectivesParser.CBrace, 0); }
		public ForStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forStatement; }
	}

	public final ForStatementContext forStatement() throws RecognitionException {
		ForStatementContext _localctx = new ForStatementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_forStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			match(T__2);
			setState(144);
			match(OParen);
			setState(145);
			match(Identifier);
			setState(146);
			match(Assign);
			setState(147);
			expression();
			setState(148);
			match(SColon);
			setState(149);
			expression();
			setState(150);
			match(SColon);
			setState(151);
			expression();
			setState(152);
			match(CParen);
			setState(153);
			match(OBrace);
			setState(154);
			statements();
			setState(155);
			match(CBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MacroContext extends ParserRuleContext {
		public TerminalNode Dollar() { return getToken(DirectivesParser.Dollar, 0); }
		public List<TerminalNode> OBrace() { return getTokens(DirectivesParser.OBrace); }
		public TerminalNode OBrace(int i) {
			return getToken(DirectivesParser.OBrace, i);
		}
		public TerminalNode CBrace() { return getToken(DirectivesParser.CBrace, 0); }
		public List<MacroContext> macro() {
			return getRuleContexts(MacroContext.class);
		}
		public MacroContext macro(int i) {
			return getRuleContext(MacroContext.class,i);
		}
		public List<TerminalNode> Macro() { return getTokens(DirectivesParser.Macro); }
		public TerminalNode Macro(int i) {
			return getToken(DirectivesParser.Macro, i);
		}
		public MacroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_macro; }
	}

	public final MacroContext macro() throws RecognitionException {
		MacroContext _localctx = new MacroContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_macro);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(157);
			match(Dollar);
			setState(158);
			match(OBrace);
			setState(164);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			while ( _alt!=1 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1+1 ) {
					{
					setState(162);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
					case 1:
						{
						setState(159);
						_la = _input.LA(1);
						if ( _la <= 0 || (_la==OBrace) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						}
						break;
					case 2:
						{
						setState(160);
						macro();
						}
						break;
					case 3:
						{
						setState(161);
						match(Macro);
						}
						break;
					}
					} 
				}
				setState(166);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			}
			setState(167);
			match(CBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PragmaContext extends ParserRuleContext {
		public PragmaLoadDirectiveContext pragmaLoadDirective() {
			return getRuleContext(PragmaLoadDirectiveContext.class,0);
		}
		public PragmaVersionContext pragmaVersion() {
			return getRuleContext(PragmaVersionContext.class,0);
		}
		public PragmaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pragma; }
	}

	public final PragmaContext pragma() throws RecognitionException {
		PragmaContext _localctx = new PragmaContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_pragma);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(169);
			match(T__3);
			setState(172);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__4:
				{
				setState(170);
				pragmaLoadDirective();
				}
				break;
			case T__5:
				{
				setState(171);
				pragmaVersion();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PragmaLoadDirectiveContext extends ParserRuleContext {
		public IdentifierListContext identifierList() {
			return getRuleContext(IdentifierListContext.class,0);
		}
		public PragmaLoadDirectiveContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pragmaLoadDirective; }
	}

	public final PragmaLoadDirectiveContext pragmaLoadDirective() throws RecognitionException {
		PragmaLoadDirectiveContext _localctx = new PragmaLoadDirectiveContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_pragmaLoadDirective);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(174);
			match(T__4);
			setState(175);
			identifierList();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PragmaVersionContext extends ParserRuleContext {
		public TerminalNode Number() { return getToken(DirectivesParser.Number, 0); }
		public PragmaVersionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pragmaVersion; }
	}

	public final PragmaVersionContext pragmaVersion() throws RecognitionException {
		PragmaVersionContext _localctx = new PragmaVersionContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_pragmaVersion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(177);
			match(T__5);
			setState(178);
			match(Number);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CodeblockContext extends ParserRuleContext {
		public TerminalNode Colon() { return getToken(DirectivesParser.Colon, 0); }
		public ConditionContext condition() {
			return getRuleContext(ConditionContext.class,0);
		}
		public List<TerminalNode> Space() { return getTokens(DirectivesParser.Space); }
		public TerminalNode Space(int i) {
			return getToken(DirectivesParser.Space, i);
		}
		public CodeblockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_codeblock; }
	}

	public final CodeblockContext codeblock() throws RecognitionException {
		CodeblockContext _localctx = new CodeblockContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_codeblock);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(180);
			match(T__6);
			setState(184);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Space) {
				{
				{
				setState(181);
				match(Space);
				}
				}
				setState(186);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(187);
			match(Colon);
			setState(188);
			condition();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(DirectivesParser.Identifier, 0); }
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_identifier);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(190);
			match(Identifier);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PropertiesContext extends ParserRuleContext {
		public TerminalNode Colon() { return getToken(DirectivesParser.Colon, 0); }
		public List<TerminalNode> OBrace() { return getTokens(DirectivesParser.OBrace); }
		public TerminalNode OBrace(int i) {
			return getToken(DirectivesParser.OBrace, i);
		}
		public List<TerminalNode> CBrace() { return getTokens(DirectivesParser.CBrace); }
		public TerminalNode CBrace(int i) {
			return getToken(DirectivesParser.CBrace, i);
		}
		public List<PropertyListContext> propertyList() {
			return getRuleContexts(PropertyListContext.class);
		}
		public PropertyListContext propertyList(int i) {
			return getRuleContext(PropertyListContext.class,i);
		}
		public PropertiesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_properties; }
	}

	public final PropertiesContext properties() throws RecognitionException {
		PropertiesContext _localctx = new PropertiesContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_properties);
		int _la;
		try {
			int _alt;
			setState(246);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,17,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(192);
				match(T__7);
				setState(193);
				match(Colon);
				setState(194);
				match(OBrace);
				setState(196); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(195);
					propertyList();
					}
					}
					setState(198); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==Identifier );
				setState(200);
				match(CBrace);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(202);
				match(T__7);
				setState(203);
				match(Colon);
				setState(204);
				match(OBrace);
				setState(205);
				match(OBrace);
				setState(207); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(206);
					propertyList();
					}
					}
					setState(209); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==Identifier );
				setState(211);
				match(CBrace);
				 notifyErrorListeners("Too many start paranthesis"); 
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(214);
				match(T__7);
				setState(215);
				match(Colon);
				setState(216);
				match(OBrace);
				setState(218); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(217);
					propertyList();
					}
					}
					setState(220); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==Identifier );
				setState(222);
				match(CBrace);
				setState(223);
				match(CBrace);
				 notifyErrorListeners("Too many start paranthesis"); 
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(226);
				match(T__7);
				setState(227);
				match(Colon);
				setState(229); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(228);
					propertyList();
					}
					}
					setState(231); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==Identifier );
				setState(233);
				match(CBrace);
				 notifyErrorListeners("Missing opening brace"); 
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(236);
				match(T__7);
				setState(237);
				match(Colon);
				setState(238);
				match(OBrace);
				setState(240); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(239);
						propertyList();
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(242); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,16,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				 notifyErrorListeners("Missing closing brace"); 
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PropertyListContext extends ParserRuleContext {
		public List<PropertyContext> property() {
			return getRuleContexts(PropertyContext.class);
		}
		public PropertyContext property(int i) {
			return getRuleContext(PropertyContext.class,i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public PropertyListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_propertyList; }
	}

	public final PropertyListContext propertyList() throws RecognitionException {
		PropertyListContext _localctx = new PropertyListContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_propertyList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(248);
			property();
			setState(253);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Comma) {
				{
				{
				setState(249);
				match(Comma);
				setState(250);
				property();
				}
				}
				setState(255);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PropertyContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(DirectivesParser.Identifier, 0); }
		public TerminalNode Assign() { return getToken(DirectivesParser.Assign, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public BoolContext bool() {
			return getRuleContext(BoolContext.class,0);
		}
		public PropertyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_property; }
	}

	public final PropertyContext property() throws RecognitionException {
		PropertyContext _localctx = new PropertyContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_property);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(256);
			match(Identifier);
			setState(257);
			match(Assign);
			setState(261);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case String:
				{
				setState(258);
				text();
				}
				break;
			case Number:
				{
				setState(259);
				number();
				}
				break;
			case Bool:
				{
				setState(260);
				bool();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumberRangesContext extends ParserRuleContext {
		public List<NumberRangeContext> numberRange() {
			return getRuleContexts(NumberRangeContext.class);
		}
		public NumberRangeContext numberRange(int i) {
			return getRuleContext(NumberRangeContext.class,i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public NumberRangesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numberRanges; }
	}

	public final NumberRangesContext numberRanges() throws RecognitionException {
		NumberRangesContext _localctx = new NumberRangesContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_numberRanges);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(263);
			numberRange();
			setState(268);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Comma) {
				{
				{
				setState(264);
				match(Comma);
				setState(265);
				numberRange();
				}
				}
				setState(270);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumberRangeContext extends ParserRuleContext {
		public List<TerminalNode> Number() { return getTokens(DirectivesParser.Number); }
		public TerminalNode Number(int i) {
			return getToken(DirectivesParser.Number, i);
		}
		public TerminalNode Colon() { return getToken(DirectivesParser.Colon, 0); }
		public TerminalNode Assign() { return getToken(DirectivesParser.Assign, 0); }
		public ValueContext value() {
			return getRuleContext(ValueContext.class,0);
		}
		public NumberRangeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numberRange; }
	}

	public final NumberRangeContext numberRange() throws RecognitionException {
		NumberRangeContext _localctx = new NumberRangeContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_numberRange);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(271);
			match(Number);
			setState(272);
			match(Colon);
			setState(273);
			match(Number);
			setState(274);
			match(Assign);
			setState(275);
			value();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueContext extends ParserRuleContext {
		public TerminalNode String() { return getToken(DirectivesParser.String, 0); }
		public TerminalNode Number() { return getToken(DirectivesParser.Number, 0); }
		public TerminalNode Column() { return getToken(DirectivesParser.Column, 0); }
		public TerminalNode Bool() { return getToken(DirectivesParser.Bool, 0); }
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_value);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(277);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 3674937295934324736L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EcommandContext extends ParserRuleContext {
		public TerminalNode External() { return getToken(DirectivesParser.External, 0); }
		public TerminalNode Identifier() { return getToken(DirectivesParser.Identifier, 0); }
		public EcommandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ecommand; }
	}

	public final EcommandContext ecommand() throws RecognitionException {
		EcommandContext _localctx = new EcommandContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_ecommand);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(279);
			match(External);
			setState(280);
			match(Identifier);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConfigContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(DirectivesParser.Identifier, 0); }
		public ConfigContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_config; }
	}

	public final ConfigContext config() throws RecognitionException {
		ConfigContext _localctx = new ConfigContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_config);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(282);
			match(Identifier);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColumnContext extends ParserRuleContext {
		public TerminalNode Column() { return getToken(DirectivesParser.Column, 0); }
		public ColumnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_column; }
	}

	public final ColumnContext column() throws RecognitionException {
		ColumnContext _localctx = new ColumnContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_column);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(284);
			match(Column);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TextContext extends ParserRuleContext {
		public TerminalNode String() { return getToken(DirectivesParser.String, 0); }
		public TextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_text; }
	}

	public final TextContext text() throws RecognitionException {
		TextContext _localctx = new TextContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_text);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(286);
			match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumberContext extends ParserRuleContext {
		public TerminalNode Number() { return getToken(DirectivesParser.Number, 0); }
		public NumberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_number; }
	}

	public final NumberContext number() throws RecognitionException {
		NumberContext _localctx = new NumberContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_number);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(288);
			match(Number);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BoolContext extends ParserRuleContext {
		public TerminalNode Bool() { return getToken(DirectivesParser.Bool, 0); }
		public BoolContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bool; }
	}

	public final BoolContext bool() throws RecognitionException {
		BoolContext _localctx = new BoolContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_bool);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(290);
			match(Bool);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConditionContext extends ParserRuleContext {
		public TerminalNode OBrace() { return getToken(DirectivesParser.OBrace, 0); }
		public List<TerminalNode> CBrace() { return getTokens(DirectivesParser.CBrace); }
		public TerminalNode CBrace(int i) {
			return getToken(DirectivesParser.CBrace, i);
		}
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public ConditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition; }
	}

	public final ConditionContext condition() throws RecognitionException {
		ConditionContext _localctx = new ConditionContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_condition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(292);
			match(OBrace);
			setState(297);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 1)) & ~0x3f) == 0 && ((1L << (_la - 1)) & -513L) != 0)) {
				{
				setState(295);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
				case 1:
					{
					setState(293);
					_la = _input.LA(1);
					if ( _la <= 0 || (_la==CBrace) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					break;
				case 2:
					{
					setState(294);
					condition();
					}
					break;
				}
				}
				setState(299);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(300);
			match(CBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CommandContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(DirectivesParser.Identifier, 0); }
		public CommandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_command; }
	}

	public final CommandContext command() throws RecognitionException {
		CommandContext _localctx = new CommandContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_command);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(302);
			match(Identifier);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColListContext extends ParserRuleContext {
		public List<TerminalNode> Column() { return getTokens(DirectivesParser.Column); }
		public TerminalNode Column(int i) {
			return getToken(DirectivesParser.Column, i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public ColListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_colList; }
	}

	public final ColListContext colList() throws RecognitionException {
		ColListContext _localctx = new ColListContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_colList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(304);
			match(Column);
			setState(307); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(305);
				match(Comma);
				setState(306);
				match(Column);
				}
				}
				setState(309); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==Comma );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumberListContext extends ParserRuleContext {
		public List<TerminalNode> Number() { return getTokens(DirectivesParser.Number); }
		public TerminalNode Number(int i) {
			return getToken(DirectivesParser.Number, i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public NumberListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numberList; }
	}

	public final NumberListContext numberList() throws RecognitionException {
		NumberListContext _localctx = new NumberListContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_numberList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(311);
			match(Number);
			setState(314); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(312);
				match(Comma);
				setState(313);
				match(Number);
				}
				}
				setState(316); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==Comma );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BoolListContext extends ParserRuleContext {
		public List<TerminalNode> Bool() { return getTokens(DirectivesParser.Bool); }
		public TerminalNode Bool(int i) {
			return getToken(DirectivesParser.Bool, i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public BoolListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolList; }
	}

	public final BoolListContext boolList() throws RecognitionException {
		BoolListContext _localctx = new BoolListContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_boolList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(318);
			match(Bool);
			setState(321); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(319);
				match(Comma);
				setState(320);
				match(Bool);
				}
				}
				setState(323); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==Comma );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StringListContext extends ParserRuleContext {
		public List<TerminalNode> String() { return getTokens(DirectivesParser.String); }
		public TerminalNode String(int i) {
			return getToken(DirectivesParser.String, i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public StringListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringList; }
	}

	public final StringListContext stringList() throws RecognitionException {
		StringListContext _localctx = new StringListContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_stringList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(325);
			match(String);
			setState(328); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(326);
				match(Comma);
				setState(327);
				match(String);
				}
				}
				setState(330); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==Comma );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierListContext extends ParserRuleContext {
		public List<TerminalNode> Identifier() { return getTokens(DirectivesParser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(DirectivesParser.Identifier, i);
		}
		public List<TerminalNode> Comma() { return getTokens(DirectivesParser.Comma); }
		public TerminalNode Comma(int i) {
			return getToken(DirectivesParser.Comma, i);
		}
		public IdentifierListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifierList; }
	}

	public final IdentifierListContext identifierList() throws RecognitionException {
		IdentifierListContext _localctx = new IdentifierListContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_identifierList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(332);
			match(Identifier);
			setState(337);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Comma) {
				{
				{
				setState(333);
				match(Comma);
				setState(334);
				match(Identifier);
				}
				}
				setState(339);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001@\u0155\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0001\u0000\u0001"+
		"\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0005\u0001Q\b"+
		"\u0001\n\u0001\f\u0001T\t\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0005\u0002d\b"+
		"\u0002\n\u0002\f\u0002g\t\u0002\u0001\u0003\u0001\u0003\u0005\u0003k\b"+
		"\u0003\n\u0003\f\u0003n\t\u0003\u0001\u0003\u0003\u0003q\b\u0003\u0001"+
		"\u0003\u0001\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001"+
		"\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0005\u0007\u0089\b\u0007\n"+
		"\u0007\f\u0007\u008c\t\u0007\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001"+
		"\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001"+
		"\b\u0001\b\u0001\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0005\t\u00a3"+
		"\b\t\n\t\f\t\u00a6\t\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0003\n"+
		"\u00ad\b\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0001\f"+
		"\u0001\r\u0001\r\u0005\r\u00b7\b\r\n\r\f\r\u00ba\t\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f"+
		"\u0004\u000f\u00c5\b\u000f\u000b\u000f\f\u000f\u00c6\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0004"+
		"\u000f\u00d0\b\u000f\u000b\u000f\f\u000f\u00d1\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0004\u000f"+
		"\u00db\b\u000f\u000b\u000f\f\u000f\u00dc\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0004\u000f\u00e6"+
		"\b\u000f\u000b\u000f\f\u000f\u00e7\u0001\u000f\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0004\u000f\u00f1\b\u000f"+
		"\u000b\u000f\f\u000f\u00f2\u0001\u000f\u0001\u000f\u0003\u000f\u00f7\b"+
		"\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0005\u0010\u00fc\b\u0010\n"+
		"\u0010\f\u0010\u00ff\t\u0010\u0001\u0011\u0001\u0011\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0003\u0011\u0106\b\u0011\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0005\u0012\u010b\b\u0012\n\u0012\f\u0012\u010e\t\u0012\u0001\u0013"+
		"\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0014"+
		"\u0001\u0014\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0016\u0001\u0016"+
		"\u0001\u0017\u0001\u0017\u0001\u0018\u0001\u0018\u0001\u0019\u0001\u0019"+
		"\u0001\u001a\u0001\u001a\u0001\u001b\u0001\u001b\u0001\u001b\u0005\u001b"+
		"\u0128\b\u001b\n\u001b\f\u001b\u012b\t\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001c\u0001\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0004\u001d\u0134"+
		"\b\u001d\u000b\u001d\f\u001d\u0135\u0001\u001e\u0001\u001e\u0001\u001e"+
		"\u0004\u001e\u013b\b\u001e\u000b\u001e\f\u001e\u013c\u0001\u001f\u0001"+
		"\u001f\u0001\u001f\u0004\u001f\u0142\b\u001f\u000b\u001f\f\u001f\u0143"+
		"\u0001 \u0001 \u0001 \u0004 \u0149\b \u000b \f \u014a\u0001!\u0001!\u0001"+
		"!\u0005!\u0150\b!\n!\f!\u0153\t!\u0001!\u0002e\u00a4\u0000\"\u0000\u0002"+
		"\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e"+
		" \"$&(*,.02468:<>@B\u0000\u0004\u0001\u0000,,\u0001\u0000\t\t\u0002\u0000"+
		"89<=\u0001\u0000\n\n\u0161\u0000D\u0001\u0000\u0000\u0000\u0002R\u0001"+
		"\u0000\u0000\u0000\u0004U\u0001\u0000\u0000\u0000\u0006h\u0001\u0000\u0000"+
		"\u0000\bt\u0001\u0000\u0000\u0000\ny\u0001\u0000\u0000\u0000\f\u0080\u0001"+
		"\u0000\u0000\u0000\u000e\u0085\u0001\u0000\u0000\u0000\u0010\u008f\u0001"+
		"\u0000\u0000\u0000\u0012\u009d\u0001\u0000\u0000\u0000\u0014\u00a9\u0001"+
		"\u0000\u0000\u0000\u0016\u00ae\u0001\u0000\u0000\u0000\u0018\u00b1\u0001"+
		"\u0000\u0000\u0000\u001a\u00b4\u0001\u0000\u0000\u0000\u001c\u00be\u0001"+
		"\u0000\u0000\u0000\u001e\u00f6\u0001\u0000\u0000\u0000 \u00f8\u0001\u0000"+
		"\u0000\u0000\"\u0100\u0001\u0000\u0000\u0000$\u0107\u0001\u0000\u0000"+
		"\u0000&\u010f\u0001\u0000\u0000\u0000(\u0115\u0001\u0000\u0000\u0000*"+
		"\u0117\u0001\u0000\u0000\u0000,\u011a\u0001\u0000\u0000\u0000.\u011c\u0001"+
		"\u0000\u0000\u00000\u011e\u0001\u0000\u0000\u00002\u0120\u0001\u0000\u0000"+
		"\u00004\u0122\u0001\u0000\u0000\u00006\u0124\u0001\u0000\u0000\u00008"+
		"\u012e\u0001\u0000\u0000\u0000:\u0130\u0001\u0000\u0000\u0000<\u0137\u0001"+
		"\u0000\u0000\u0000>\u013e\u0001\u0000\u0000\u0000@\u0145\u0001\u0000\u0000"+
		"\u0000B\u014c\u0001\u0000\u0000\u0000DE\u0003\u0002\u0001\u0000EF\u0005"+
		"\u0000\u0000\u0001F\u0001\u0001\u0000\u0000\u0000GQ\u0005?\u0000\u0000"+
		"HQ\u0003\u0012\t\u0000IJ\u0003\u0004\u0002\u0000JK\u0005\u000b\u0000\u0000"+
		"KQ\u0001\u0000\u0000\u0000LM\u0003\u0014\n\u0000MN\u0005\u000b\u0000\u0000"+
		"NQ\u0001\u0000\u0000\u0000OQ\u0003\u0006\u0003\u0000PG\u0001\u0000\u0000"+
		"\u0000PH\u0001\u0000\u0000\u0000PI\u0001\u0000\u0000\u0000PL\u0001\u0000"+
		"\u0000\u0000PO\u0001\u0000\u0000\u0000QT\u0001\u0000\u0000\u0000RP\u0001"+
		"\u0000\u0000\u0000RS\u0001\u0000\u0000\u0000S\u0003\u0001\u0000\u0000"+
		"\u0000TR\u0001\u0000\u0000\u0000Ue\u00038\u001c\u0000Vd\u0003\u001a\r"+
		"\u0000Wd\u0003\u001c\u000e\u0000Xd\u0003\u0012\t\u0000Yd\u00030\u0018"+
		"\u0000Zd\u00032\u0019\u0000[d\u00034\u001a\u0000\\d\u0003.\u0017\u0000"+
		"]d\u0003:\u001d\u0000^d\u0003<\u001e\u0000_d\u0003>\u001f\u0000`d\u0003"+
		"@ \u0000ad\u0003$\u0012\u0000bd\u0003\u001e\u000f\u0000cV\u0001\u0000"+
		"\u0000\u0000cW\u0001\u0000\u0000\u0000cX\u0001\u0000\u0000\u0000cY\u0001"+
		"\u0000\u0000\u0000cZ\u0001\u0000\u0000\u0000c[\u0001\u0000\u0000\u0000"+
		"c\\\u0001\u0000\u0000\u0000c]\u0001\u0000\u0000\u0000c^\u0001\u0000\u0000"+
		"\u0000c_\u0001\u0000\u0000\u0000c`\u0001\u0000\u0000\u0000ca\u0001\u0000"+
		"\u0000\u0000cb\u0001\u0000\u0000\u0000dg\u0001\u0000\u0000\u0000ef\u0001"+
		"\u0000\u0000\u0000ec\u0001\u0000\u0000\u0000f\u0005\u0001\u0000\u0000"+
		"\u0000ge\u0001\u0000\u0000\u0000hl\u0003\b\u0004\u0000ik\u0003\n\u0005"+
		"\u0000ji\u0001\u0000\u0000\u0000kn\u0001\u0000\u0000\u0000lj\u0001\u0000"+
		"\u0000\u0000lm\u0001\u0000\u0000\u0000mp\u0001\u0000\u0000\u0000nl\u0001"+
		"\u0000\u0000\u0000oq\u0003\f\u0006\u0000po\u0001\u0000\u0000\u0000pq\u0001"+
		"\u0000\u0000\u0000qr\u0001\u0000\u0000\u0000rs\u0005\n\u0000\u0000s\u0007"+
		"\u0001\u0000\u0000\u0000tu\u0005\u0001\u0000\u0000uv\u0003\u000e\u0007"+
		"\u0000vw\u0005\t\u0000\u0000wx\u0003\u0002\u0001\u0000x\t\u0001\u0000"+
		"\u0000\u0000yz\u0005\n\u0000\u0000z{\u0005\u0002\u0000\u0000{|\u0005\u0001"+
		"\u0000\u0000|}\u0003\u000e\u0007\u0000}~\u0005\t\u0000\u0000~\u007f\u0003"+
		"\u0002\u0001\u0000\u007f\u000b\u0001\u0000\u0000\u0000\u0080\u0081\u0005"+
		"\n\u0000\u0000\u0081\u0082\u0005\u0002\u0000\u0000\u0082\u0083\u0005\t"+
		"\u0000\u0000\u0083\u0084\u0003\u0002\u0001\u0000\u0084\r\u0001\u0000\u0000"+
		"\u0000\u0085\u008a\u0005,\u0000\u0000\u0086\u0089\b\u0000\u0000\u0000"+
		"\u0087\u0089\u0003\u000e\u0007\u0000\u0088\u0086\u0001\u0000\u0000\u0000"+
		"\u0088\u0087\u0001\u0000\u0000\u0000\u0089\u008c\u0001\u0000\u0000\u0000"+
		"\u008a\u0088\u0001\u0000\u0000\u0000\u008a\u008b\u0001\u0000\u0000\u0000"+
		"\u008b\u008d\u0001\u0000\u0000\u0000\u008c\u008a\u0001\u0000\u0000\u0000"+
		"\u008d\u008e\u0005-\u0000\u0000\u008e\u000f\u0001\u0000\u0000\u0000\u008f"+
		"\u0090\u0005\u0003\u0000\u0000\u0090\u0091\u0005,\u0000\u0000\u0091\u0092"+
		"\u0005:\u0000\u0000\u0092\u0093\u0005.\u0000\u0000\u0093\u0094\u0003\u000e"+
		"\u0007\u0000\u0094\u0095\u0005\u000b\u0000\u0000\u0095\u0096\u0003\u000e"+
		"\u0007\u0000\u0096\u0097\u0005\u000b\u0000\u0000\u0097\u0098\u0003\u000e"+
		"\u0007\u0000\u0098\u0099\u0005-\u0000\u0000\u0099\u009a\u0005\t\u0000"+
		"\u0000\u009a\u009b\u0003\u0002\u0001\u0000\u009b\u009c\u0005\n\u0000\u0000"+
		"\u009c\u0011\u0001\u0000\u0000\u0000\u009d\u009e\u00056\u0000\u0000\u009e"+
		"\u00a4\u0005\t\u0000\u0000\u009f\u00a3\b\u0001\u0000\u0000\u00a0\u00a3"+
		"\u0003\u0012\t\u0000\u00a1\u00a3\u0005;\u0000\u0000\u00a2\u009f\u0001"+
		"\u0000\u0000\u0000\u00a2\u00a0\u0001\u0000\u0000\u0000\u00a2\u00a1\u0001"+
		"\u0000\u0000\u0000\u00a3\u00a6\u0001\u0000\u0000\u0000\u00a4\u00a5\u0001"+
		"\u0000\u0000\u0000\u00a4\u00a2\u0001\u0000\u0000\u0000\u00a5\u00a7\u0001"+
		"\u0000\u0000\u0000\u00a6\u00a4\u0001\u0000\u0000\u0000\u00a7\u00a8\u0005"+
		"\n\u0000\u0000\u00a8\u0013\u0001\u0000\u0000\u0000\u00a9\u00ac\u0005\u0004"+
		"\u0000\u0000\u00aa\u00ad\u0003\u0016\u000b\u0000\u00ab\u00ad\u0003\u0018"+
		"\f\u0000\u00ac\u00aa\u0001\u0000\u0000\u0000\u00ac\u00ab\u0001\u0000\u0000"+
		"\u0000\u00ad\u0015\u0001\u0000\u0000\u0000\u00ae\u00af\u0005\u0005\u0000"+
		"\u0000\u00af\u00b0\u0003B!\u0000\u00b0\u0017\u0001\u0000\u0000\u0000\u00b1"+
		"\u00b2\u0005\u0006\u0000\u0000\u00b2\u00b3\u00059\u0000\u0000\u00b3\u0019"+
		"\u0001\u0000\u0000\u0000\u00b4\u00b8\u0005\u0007\u0000\u0000\u00b5\u00b7"+
		"\u0005@\u0000\u0000\u00b6\u00b5\u0001\u0000\u0000\u0000\u00b7\u00ba\u0001"+
		"\u0000\u0000\u0000\u00b8\u00b6\u0001\u0000\u0000\u0000\u00b8\u00b9\u0001"+
		"\u0000\u0000\u0000\u00b9\u00bb\u0001\u0000\u0000\u0000\u00ba\u00b8\u0001"+
		"\u0000\u0000\u0000\u00bb\u00bc\u00051\u0000\u0000\u00bc\u00bd\u00036\u001b"+
		"\u0000\u00bd\u001b\u0001\u0000\u0000\u0000\u00be\u00bf\u0005:\u0000\u0000"+
		"\u00bf\u001d\u0001\u0000\u0000\u0000\u00c0\u00c1\u0005\b\u0000\u0000\u00c1"+
		"\u00c2\u00051\u0000\u0000\u00c2\u00c4\u0005\t\u0000\u0000\u00c3\u00c5"+
		"\u0003 \u0010\u0000\u00c4\u00c3\u0001\u0000\u0000\u0000\u00c5\u00c6\u0001"+
		"\u0000\u0000\u0000\u00c6\u00c4\u0001\u0000\u0000\u0000\u00c6\u00c7\u0001"+
		"\u0000\u0000\u0000\u00c7\u00c8\u0001\u0000\u0000\u0000\u00c8\u00c9\u0005"+
		"\n\u0000\u0000\u00c9\u00f7\u0001\u0000\u0000\u0000\u00ca\u00cb\u0005\b"+
		"\u0000\u0000\u00cb\u00cc\u00051\u0000\u0000\u00cc\u00cd\u0005\t\u0000"+
		"\u0000\u00cd\u00cf\u0005\t\u0000\u0000\u00ce\u00d0\u0003 \u0010\u0000"+
		"\u00cf\u00ce\u0001\u0000\u0000\u0000\u00d0\u00d1\u0001\u0000\u0000\u0000"+
		"\u00d1\u00cf\u0001\u0000\u0000\u0000\u00d1\u00d2\u0001\u0000\u0000\u0000"+
		"\u00d2\u00d3\u0001\u0000\u0000\u0000\u00d3\u00d4\u0005\n\u0000\u0000\u00d4"+
		"\u00d5\u0006\u000f\uffff\uffff\u0000\u00d5\u00f7\u0001\u0000\u0000\u0000"+
		"\u00d6\u00d7\u0005\b\u0000\u0000\u00d7\u00d8\u00051\u0000\u0000\u00d8"+
		"\u00da\u0005\t\u0000\u0000\u00d9\u00db\u0003 \u0010\u0000\u00da\u00d9"+
		"\u0001\u0000\u0000\u0000\u00db\u00dc\u0001\u0000\u0000\u0000\u00dc\u00da"+
		"\u0001\u0000\u0000\u0000\u00dc\u00dd\u0001\u0000\u0000\u0000\u00dd\u00de"+
		"\u0001\u0000\u0000\u0000\u00de\u00df\u0005\n\u0000\u0000\u00df\u00e0\u0005"+
		"\n\u0000\u0000\u00e0\u00e1\u0006\u000f\uffff\uffff\u0000\u00e1\u00f7\u0001"+
		"\u0000\u0000\u0000\u00e2\u00e3\u0005\b\u0000\u0000\u00e3\u00e5\u00051"+
		"\u0000\u0000\u00e4\u00e6\u0003 \u0010\u0000\u00e5\u00e4\u0001\u0000\u0000"+
		"\u0000\u00e6\u00e7\u0001\u0000\u0000\u0000\u00e7\u00e5\u0001\u0000\u0000"+
		"\u0000\u00e7\u00e8\u0001\u0000\u0000\u0000\u00e8\u00e9\u0001\u0000\u0000"+
		"\u0000\u00e9\u00ea\u0005\n\u0000\u0000\u00ea\u00eb\u0006\u000f\uffff\uffff"+
		"\u0000\u00eb\u00f7\u0001\u0000\u0000\u0000\u00ec\u00ed\u0005\b\u0000\u0000"+
		"\u00ed\u00ee\u00051\u0000\u0000\u00ee\u00f0\u0005\t\u0000\u0000\u00ef"+
		"\u00f1\u0003 \u0010\u0000\u00f0\u00ef\u0001\u0000\u0000\u0000\u00f1\u00f2"+
		"\u0001\u0000\u0000\u0000\u00f2\u00f0\u0001\u0000\u0000\u0000\u00f2\u00f3"+
		"\u0001\u0000\u0000\u0000\u00f3\u00f4\u0001\u0000\u0000\u0000\u00f4\u00f5"+
		"\u0006\u000f\uffff\uffff\u0000\u00f5\u00f7\u0001\u0000\u0000\u0000\u00f6"+
		"\u00c0\u0001\u0000\u0000\u0000\u00f6\u00ca\u0001\u0000\u0000\u0000\u00f6"+
		"\u00d6\u0001\u0000\u0000\u0000\u00f6\u00e2\u0001\u0000\u0000\u0000\u00f6"+
		"\u00ec\u0001\u0000\u0000\u0000\u00f7\u001f\u0001\u0000\u0000\u0000\u00f8"+
		"\u00fd\u0003\"\u0011\u0000\u00f9\u00fa\u0005/\u0000\u0000\u00fa\u00fc"+
		"\u0003\"\u0011\u0000\u00fb\u00f9\u0001\u0000\u0000\u0000\u00fc\u00ff\u0001"+
		"\u0000\u0000\u0000\u00fd\u00fb\u0001\u0000\u0000\u0000\u00fd\u00fe\u0001"+
		"\u0000\u0000\u0000\u00fe!\u0001\u0000\u0000\u0000\u00ff\u00fd\u0001\u0000"+
		"\u0000\u0000\u0100\u0101\u0005:\u0000\u0000\u0101\u0105\u0005.\u0000\u0000"+
		"\u0102\u0106\u00030\u0018\u0000\u0103\u0106\u00032\u0019\u0000\u0104\u0106"+
		"\u00034\u001a\u0000\u0105\u0102\u0001\u0000\u0000\u0000\u0105\u0103\u0001"+
		"\u0000\u0000\u0000\u0105\u0104\u0001\u0000\u0000\u0000\u0106#\u0001\u0000"+
		"\u0000\u0000\u0107\u010c\u0003&\u0013\u0000\u0108\u0109\u0005/\u0000\u0000"+
		"\u0109\u010b\u0003&\u0013\u0000\u010a\u0108\u0001\u0000\u0000\u0000\u010b"+
		"\u010e\u0001\u0000\u0000\u0000\u010c\u010a\u0001\u0000\u0000\u0000\u010c"+
		"\u010d\u0001\u0000\u0000\u0000\u010d%\u0001\u0000\u0000\u0000\u010e\u010c"+
		"\u0001\u0000\u0000\u0000\u010f\u0110\u00059\u0000\u0000\u0110\u0111\u0005"+
		"1\u0000\u0000\u0111\u0112\u00059\u0000\u0000\u0112\u0113\u0005.\u0000"+
		"\u0000\u0113\u0114\u0003(\u0014\u0000\u0114\'\u0001\u0000\u0000\u0000"+
		"\u0115\u0116\u0007\u0002\u0000\u0000\u0116)\u0001\u0000\u0000\u0000\u0117"+
		"\u0118\u0005\"\u0000\u0000\u0118\u0119\u0005:\u0000\u0000\u0119+\u0001"+
		"\u0000\u0000\u0000\u011a\u011b\u0005:\u0000\u0000\u011b-\u0001\u0000\u0000"+
		"\u0000\u011c\u011d\u0005<\u0000\u0000\u011d/\u0001\u0000\u0000\u0000\u011e"+
		"\u011f\u0005=\u0000\u0000\u011f1\u0001\u0000\u0000\u0000\u0120\u0121\u0005"+
		"9\u0000\u0000\u01213\u0001\u0000\u0000\u0000\u0122\u0123\u00058\u0000"+
		"\u0000\u01235\u0001\u0000\u0000\u0000\u0124\u0129\u0005\t\u0000\u0000"+
		"\u0125\u0128\b\u0003\u0000\u0000\u0126\u0128\u00036\u001b\u0000\u0127"+
		"\u0125\u0001\u0000\u0000\u0000\u0127\u0126\u0001\u0000\u0000\u0000\u0128"+
		"\u012b\u0001\u0000\u0000\u0000\u0129\u0127\u0001\u0000\u0000\u0000\u0129"+
		"\u012a\u0001\u0000\u0000\u0000\u012a\u012c\u0001\u0000\u0000\u0000\u012b"+
		"\u0129\u0001\u0000\u0000\u0000\u012c\u012d\u0005\n\u0000\u0000\u012d7"+
		"\u0001\u0000\u0000\u0000\u012e\u012f\u0005:\u0000\u0000\u012f9\u0001\u0000"+
		"\u0000\u0000\u0130\u0133\u0005<\u0000\u0000\u0131\u0132\u0005/\u0000\u0000"+
		"\u0132\u0134\u0005<\u0000\u0000\u0133\u0131\u0001\u0000\u0000\u0000\u0134"+
		"\u0135\u0001\u0000\u0000\u0000\u0135\u0133\u0001\u0000\u0000\u0000\u0135"+
		"\u0136\u0001\u0000\u0000\u0000\u0136;\u0001\u0000\u0000\u0000\u0137\u013a"+
		"\u00059\u0000\u0000\u0138\u0139\u0005/\u0000\u0000\u0139\u013b\u00059"+
		"\u0000\u0000\u013a\u0138\u0001\u0000\u0000\u0000\u013b\u013c\u0001\u0000"+
		"\u0000\u0000\u013c\u013a\u0001\u0000\u0000\u0000\u013c\u013d\u0001\u0000"+
		"\u0000\u0000\u013d=\u0001\u0000\u0000\u0000\u013e\u0141\u00058\u0000\u0000"+
		"\u013f\u0140\u0005/\u0000\u0000\u0140\u0142\u00058\u0000\u0000\u0141\u013f"+
		"\u0001\u0000\u0000\u0000\u0142\u0143\u0001\u0000\u0000\u0000\u0143\u0141"+
		"\u0001\u0000\u0000\u0000\u0143\u0144\u0001\u0000\u0000\u0000\u0144?\u0001"+
		"\u0000\u0000\u0000\u0145\u0148\u0005=\u0000\u0000\u0146\u0147\u0005/\u0000"+
		"\u0000\u0147\u0149\u0005=\u0000\u0000\u0148\u0146\u0001\u0000\u0000\u0000"+
		"\u0149\u014a\u0001\u0000\u0000\u0000\u014a\u0148\u0001\u0000\u0000\u0000"+
		"\u014a\u014b\u0001\u0000\u0000\u0000\u014bA\u0001\u0000\u0000\u0000\u014c"+
		"\u0151\u0005:\u0000\u0000\u014d\u014e\u0005/\u0000\u0000\u014e\u0150\u0005"+
		":\u0000\u0000\u014f\u014d\u0001\u0000\u0000\u0000\u0150\u0153\u0001\u0000"+
		"\u0000\u0000\u0151\u014f\u0001\u0000\u0000\u0000\u0151\u0152\u0001\u0000"+
		"\u0000\u0000\u0152C\u0001\u0000\u0000\u0000\u0153\u0151\u0001\u0000\u0000"+
		"\u0000\u001cPRcelp\u0088\u008a\u00a2\u00a4\u00ac\u00b8\u00c6\u00d1\u00dc"+
		"\u00e7\u00f2\u00f6\u00fd\u0105\u010c\u0127\u0129\u0135\u013c\u0143\u014a"+
		"\u0151";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}